import { Client } from "@stomp/stompjs";

export function connectChat(accessToken, chatRoomId) {
  const client = new Client({
    brokerURL: "ws://127.0.0.1:8080/ws",

    connectHeaders: {
      Authorization: `Bearer ${accessToken}`,
    },

    reconnectDelay: 0,

    debug: (message) => {
      console.log("[STOMP]", message);
    },

    onConnect: () => {
      console.log("✅ WebSocket 연결 성공!");

      // 채팅방 구독
      client.subscribe(`/topic/chats/${chatRoomId}`, (message) => {
        const data = JSON.parse(message.body);

        console.log("📩 메시지 수신:", data);
      });

      console.log("✅ 채팅방 구독 성공!");
    },

    onStompError: (frame) => {
      console.error("❌ STOMP 오류:", frame.headers.message);
    },

    onWebSocketError: (error) => {
      console.error("❌ WebSocket 오류:", error);
    },
  });

  client.activate();

  return client;
}